/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectrpg;

/**
 *
 * @author Walid Hamade
 */
public class Ali extends Character {
    
    public Ali(){
        this.level = 1;
        this.exp = 0;
        this.health = 5;
        this.strength = 9;
        this.speed = 4;
        this.defense = 8;
        this.intelligence = 6 ;   // will increase the upper range of special attack
        this.luck = 2;           // will increase the upper range of defense/strength
        this.swag = 4 ;           // will increase luck and defense
        this.rarity = "rare";
        this.gifPath = "sprites/sprite_ali/Ali.gif";
    }

    @Override
    int attack() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    int specialAttack() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    void heal() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    void defend() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
