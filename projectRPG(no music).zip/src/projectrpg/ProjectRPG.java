/*
 * Project RPG
 */
package projectrpg;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.media.AudioClip;
import javafx.stage.Stage;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;

/**
 *
 * @author 7medeh
 */
public class ProjectRPG extends Application implements EventHandler<ActionEvent> {

    String BGMpath = "199[IntroMusic].aif";
    Media BGMmedia = new Media(new File(BGMpath).toURI().toString());
    AudioClip BGMmediaPlayer = new AudioClip(BGMmedia.getSource());

    public static void main(String[] args) {
        Application.launch(ProjectRPG.class, (java.lang.String[]) null);
    }

    @Override
    public void start(Stage primaryStage) {
        try {
            //Interface
            VBox page = FXMLLoader.load(ProjectRPG.class.getResource("Game.fxml"));
            Scene scene = new Scene(page);
            primaryStage.setScene(scene);
            primaryStage.setTitle("Project RPG: Walid Hamade");
            primaryStage.show();

            BGMmediaPlayer.play();

        } catch (Exception ex) {
            Logger.getLogger(ProjectRPG.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void handle(ActionEvent e) {

    }

    public void stopMusic() {
        this.BGMmediaPlayer.stop();
    }
    
    public void playMusic(String x){
        this.BGMpath = x;
        this.BGMmedia = new Media(new File(BGMpath).toURI().toString());
        this.BGMmediaPlayer = new AudioClip(BGMmedia.getSource());
        this.BGMmediaPlayer.play();
    }

}
