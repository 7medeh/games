/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectrpg;

/**
 *
 * @author Walid Hamade
 */
public class Walid extends Character{
    
    public Walid() {
        this.level = 1;
        this.exp = 0;
        this.health = 6;
        this.strength = 8;
        this.speed = 8;
        this.defense = 7;
        this.intelligence = 8;   // will increase the upper range of special attack
        this.luck = 4;           // will increase the upper range of defense/strength
        this.swag = 7;           // will increase luck and defense
        this.rarity = "rare";
        this.gifPath = "sprites/sprite_walid/Walid.gif";
    }
    @Override
    int attack() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    int specialAttack() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    void heal() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    void defend() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
