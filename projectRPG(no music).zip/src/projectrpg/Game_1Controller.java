/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectrpg;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author 7medeh
 */
public class Game_1Controller implements Initializable {

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO

    }

    public void backClicked(ActionEvent e) throws IOException {
        //when user selects new game
        Parent goBack = FXMLLoader.load(getClass().getResource("Game.fxml"));
        Scene goBackScene = new Scene(goBack);
        Stage goBackStage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        goBackStage.setScene(goBackScene);
        goBackStage.show();
    }
//For when the user selects next again
    public void nextButtonClicked(ActionEvent e) throws IOException {
        //when user selects new game
        Parent nextButton = FXMLLoader.load(getClass().getResource("Game_1_1.fxml"));
        Scene nextGameScene = new Scene(nextButton);
        Stage nextGameStage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        nextGameStage.setScene(nextGameScene);
        nextGameStage.show();
    }

}
