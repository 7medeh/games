/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectrpg;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author 7medeh
 */
public class MakeAChoiceController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO

    }

    @FXML
    public void walidClicked(ActionEvent e) throws IOException {
        //when user selects new game
        Parent new_game_mode = FXMLLoader.load(getClass().getResource("WalidChosen.fxml"));
        Scene newGame = new Scene(new_game_mode);
        Stage newGame_Stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        newGame_Stage.setScene(newGame);
        newGame_Stage.show();
    }
    @FXML
    public void lizClicked(ActionEvent e) throws IOException {
        //when user selects new game
        Parent new_game_mode = FXMLLoader.load(getClass().getResource("LizChosen.fxml"));
        Scene newGame = new Scene(new_game_mode);
        Stage newGame_Stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        newGame_Stage.setScene(newGame);
        newGame_Stage.show();
    }
    @FXML
    public void aliClicked(ActionEvent e) throws IOException {
        //when user selects new game
        Parent new_game_mode = FXMLLoader.load(getClass().getResource("AliChosen.fxml"));
        Scene newGame = new Scene(new_game_mode);
        Stage newGame_Stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        newGame_Stage.setScene(newGame);
        newGame_Stage.show();
    }

}
