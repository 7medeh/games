/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectrpg;

/**
 *
 * @author 7medeh
 */
abstract class Character implements Comparable<Character>{
    int level;
    int exp;
    int health;
    int strength;
    int speed;
    int defense;
    int intelligence;   // will increase the upper range of special attack
    int luck;           // will increase the upper range of defense/strength
    int swag;           // will increase luck and defense
    String rarity;
    String gifPath;
    
    abstract int attack();          // will return the damage dealt
    abstract int specialAttack();   // will return the damage dealt
    abstract void heal();           // will heal the character but skip the next turn
    abstract void defend();         // will defend the character
    
    @Override
    public int compareTo(Character c){
        if (this.level > c.level){
            return 1;
        }
        else if (c.level > this.level){
            return -1;
        }
        else return 0;
    }
    
   
    
    
}
