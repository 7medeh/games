/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectrpg;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author 7medeh
 */
public class Game_1_1_1_1Controller implements Initializable {

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO

    }

    @FXML
    public void backClicked2(ActionEvent e) throws IOException {
        //when user selects new game
        Parent goBack2 = FXMLLoader.load(getClass().getResource("Game_1_1_1.fxml"));
        Scene goBack2Scene = new Scene(goBack2);
        Stage goBack2Stage = (Stage)((Node)e.getSource()).getScene().getWindow();
        goBack2Stage.setScene(goBack2Scene);
        goBack2Stage.show();
    }
//For when the user selects next again
    @FXML
    public void nextButtonClicked2(ActionEvent e) throws IOException {
        //when user selects new game
        Parent nextButton2 = FXMLLoader.load(getClass().getResource("Game_1_1_1_1_1.fxml"));
        Scene nextGameScene2 = new Scene(nextButton2);
        Stage nextGameStage2 = (Stage) ((Node) e.getSource()).getScene().getWindow();
        nextGameStage2.setScene(nextGameScene2);
        nextGameStage2.show();
        
    }

}
