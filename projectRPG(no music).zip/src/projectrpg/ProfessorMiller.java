/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectrpg;

/**
 *
 * @author Walid Hamade
 */
public class ProfessorMiller extends Character {

    public ProfessorMiller() {
        this.level = 1;
        this.exp = 0;
        this.health = 10;
        this.strength = 10;
        this.speed = 10;
        this.defense = 10;
        this.intelligence = 10;   // will increase the upper range of special attack
        this.luck = 10;           // will increase the upper range of defense/strength
        this.swag = 10;           // will increase luck and defense
        this.rarity = "legendary";
        this.gifPath = "sprites/sprite_miller/LizMiller.gif";
    }

    @Override
    int attack() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    int specialAttack() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    void heal() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    void defend() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
