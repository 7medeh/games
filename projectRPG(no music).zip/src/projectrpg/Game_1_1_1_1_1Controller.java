/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectrpg;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author 7medeh
 */
public class Game_1_1_1_1_1Controller implements Initializable {

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO

    }

    @FXML
    public void backClicked2(ActionEvent e) throws IOException {
        //when user selects new game
        Parent goBack2 = FXMLLoader.load(getClass().getResource("Game_1_1_1_1.fxml"));
        Scene goBack2Scene = new Scene(goBack2);
        Stage goBack2Stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        goBack2Stage.setScene(goBack2Scene);
        goBack2Stage.show();
    }
    @FXML
    public void philosophy(ActionEvent e) throws IOException {
        Parent wizardButton = FXMLLoader.load(getClass().getResource("Philosophy.fxml"));
        Scene WizardGameScene = new Scene(wizardButton);
        Stage WizardGameStage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        WizardGameStage.setScene(WizardGameScene);
        WizardGameStage.show();
    }

    @FXML
    public void wizardry(ActionEvent e) throws IOException {
        Parent wizardButton = FXMLLoader.load(getClass().getResource("Wizardry.fxml"));
        Scene WizardGameScene = new Scene(wizardButton);
        Stage WizardGameStage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        WizardGameStage.setScene(WizardGameScene);
        WizardGameStage.show();
    }

    public void pe(ActionEvent e) throws IOException {
        Parent wizardButton = FXMLLoader.load(getClass().getResource("PhysEd.fxml"));
        Scene WizardGameScene = new Scene(wizardButton);
        Stage WizardGameStage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        WizardGameStage.setScene(WizardGameScene);
        WizardGameStage.show();
    }
    @FXML
    public void economics(ActionEvent e) throws IOException {
        Parent wizardButton = FXMLLoader.load(getClass().getResource("Economics.fxml"));
        Scene WizardGameScene = new Scene(wizardButton);
        Stage WizardGameStage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        WizardGameStage.setScene(WizardGameScene);
        WizardGameStage.show();
    }
    @FXML
    public void theCorrectChoice(ActionEvent e) throws IOException {
        Parent wizardButton = FXMLLoader.load(getClass().getResource("CorrectChoice.fxml"));
        Scene WizardGameScene = new Scene(wizardButton);
        Stage WizardGameStage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        WizardGameStage.setScene(WizardGameScene);
        WizardGameStage.show();
    }

}
