package projectpong;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 *
 * @author Walid Hamade
 */
public class Brick {

    final private int WIDTH = 80;
    final private int HEIGHT = 60;
    private double posx;
    private double posy;
    private boolean destroyed;

    public Brick(int posx, int posy) {
        this.posx = posx;
        this.posy = posy;
    }

    public boolean hitBottom(int ballPosX, int ballPosY) {
        if ((ballPosX >= posx) && (ballPosX <= posx + WIDTH) && (ballPosY == posy + HEIGHT) && (destroyed == false)) {
            return true;
        }
        return false;
    }

    public boolean hitTop(int ballPosX, int ballPosY) {
        if ((ballPosX >= posx) && (ballPosX <= posx + WIDTH) && (ballPosY == posy) && (destroyed == false)) {
            return true;
        }
        return false;
    }

    public boolean hitLeft(int ballPosX, int ballPosY) {
        if ((ballPosY >= posy) && (ballPosY <= posy + HEIGHT) && (ballPosX == posx) && (destroyed == false)) {
            return true;
        }
        return false;
    }

    public boolean hitRight(int ballPosX, int ballPosY) {
        if ((ballPosY >= posy) && (ballPosY <= posy + HEIGHT) && (ballPosX == posx + WIDTH + 2) && (destroyed == false)) {
            return true;
        }
        return false;
    }

    public void setDestroyed(boolean destroyed) {
        this.destroyed = destroyed;
    }

    boolean isDestroyed() {
        return destroyed;
    }

    public void paint(GraphicsContext g) {
        GraphicsContext g2d = (GraphicsContext) g;
        if (destroyed) {
            g2d.setFill(Color.FLORALWHITE);
            g2d.fillRect((int) posx, (int) posy, WIDTH, HEIGHT);
        }
        if (!destroyed) {
            g2d.setFill(Color.PINK);
            g2d.fillRect((int) posx, (int) posy, WIDTH, HEIGHT);

        }
    }

}
