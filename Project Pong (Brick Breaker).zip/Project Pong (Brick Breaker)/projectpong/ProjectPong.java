
package projectpong;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import java.util.Random;
import javafx.animation.KeyFrame;
import javafx.animation.PauseTransition;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.util.Duration;

/**
 *
 * @author Walid Hamade
 */
public class ProjectPong extends Application {

    //variables
    public static final int width = 800;
    public static final int height = 600;
    public static final int PLAYER_HEIGHT = 15;
    public static final int PLAYER_WIDTH = 100;
    public static final int BALL_RADIUS = 10;
    private double ballYSpeed = 1;
    private double ballXSpeed = 1;
    private double playerYPosition = height-15;
    private double playerXPosition = width / 2;
    private double ballXPosition = width / 2;
    private double ballYPosition = width / 2;
    private int playerScore = 0;
    private Brick[][] brick;
    private int bricksLeft;

    private boolean gameStarted;

    @Override
    public void start(Stage primaryStage) throws Exception {

        //Begin by setting the window title
        primaryStage.setTitle("Brick Breaker");
        Canvas canvas = new Canvas(width, height);
        GraphicsContext gc = canvas.getGraphicsContext2D();
        Timeline t1 = new Timeline(new KeyFrame(Duration.millis(10), e -> run(gc)));
        t1.setCycleCount(Timeline.INDEFINITE);

        PauseTransition wait = new PauseTransition(Duration.seconds(5));
        wait.setOnFinished((e) -> {
            checkBricks((int) ballXPosition, (int) ballYPosition);
            wait.playFromStart();
        });
        wait.play();

        //Controls
        canvas.setOnMouseMoved(e -> playerXPosition = e.getX());
        canvas.setOnMouseClicked(e -> gameStarted = true);
        primaryStage.setScene(new Scene(new StackPane(canvas)));
        primaryStage.show();
        t1.play();

    }

    private void run(GraphicsContext gc) {
        //Setting BG Color
        gc.setFill(Color.FLORALWHITE);
        gc.fillRect(0, 0, width, height);

        //Setting TEXT Color
        gc.setFill(Color.PINK);
        gc.setFont(Font.font(25));

        if (gameStarted) {
            
            ballXPosition += ballXSpeed;
            ballYPosition += ballYSpeed;
            gc.setStroke(Color.BLACK);
            gc.setTextAlign(TextAlignment.RIGHT);
            gc.strokeText("Bricks Remaining: " + bricksLeft, width - 100, height - 50);

            // Drawing the ball
            gc.fillOval(ballXPosition, ballYPosition, BALL_RADIUS, BALL_RADIUS);

            brick = new Brick[10][3];
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < 3; j++) {
                    brick[i][j] = new Brick((int) (i * (width/10) + i * 2),
                            (int) (j * (height/10) + j * 2));
                }
            }
            
            bricksLeft = 30;

        } else {
            //Display start menu
            gc.setStroke(Color.BLACK);
            gc.setTextAlign(TextAlignment.CENTER);
            gc.strokeText("Click to Begin", width / 2, height / 2);

            //reset everything else
            reset(gc);
        }

        // making the ball stay in the canvas
        if (ballXPosition > width || ballXPosition < 0) {
            ballXSpeed *= -1;
        }
        if ((ballYPosition == playerYPosition) && (ballXPosition == playerXPosition)){
            ballYSpeed *= -1;
        }
       //check brick
       checkBricks((int)ballXPosition, (int)ballYPosition);

        // if you get a point after hitting a brick
        if (ballXPosition > /*Fill in the requirements*/ +PLAYER_WIDTH) {
            playerScore++;

        }

        // ball increases in speed
        if (ballYPosition >=playerYPosition) {

            ballYSpeed += 1 * Math.signum(ballYSpeed);
            ballXSpeed += 1 * Math.signum(ballXSpeed);
            ballYSpeed *= -1;

        }
        // draw score
        gc.fillText(playerScore + "\t\t\t\t\t\t\t\t", width / 2, 100);

        // draw players
        gc.fillRect(playerXPosition, playerYPosition, PLAYER_WIDTH, PLAYER_HEIGHT);

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    public void checkBricks(int x, int y) {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 3; j++) {
                if (brick[i][j].hitBottom(x, y)) {
                    ballYSpeed = -ballYSpeed + 0.11;
                    brick[i][j].setDestroyed(true);
                    bricksLeft--;
                    if (bricksLeft == 0) {
                        gameStarted = false;
                    }
                }
                if (brick[i][j].hitLeft(x, y)) {
                    ballXSpeed = -ballXSpeed;
                    brick[i][j].setDestroyed(true);
                    bricksLeft--;
                    if (bricksLeft == 0) {
                        gameStarted = false;
                    }
                }
                if (brick[i][j].hitRight(x, y)) {
                    ballXSpeed = -ballXSpeed;
                    brick[i][j].setDestroyed(true);
                    bricksLeft--;
                    if (bricksLeft == 0) {
                        gameStarted = false;
                    }
                }
                if (brick[i][j].hitTop(x, y)) {
                    ballYSpeed = -ballYSpeed - 0.11;
                    brick[i][j].setDestroyed(true);
                    bricksLeft--;
                    if (bricksLeft == 0) {
                        gameStarted = false;
                    }
                }
            }
        }
    }

    public void reset(GraphicsContext gc) {
        //reset ball start position
        ballXPosition = width / 2;
        ballYPosition = height / 2;

        //reset speed & direction
        ballXSpeed = (new Random().nextInt(2) == 0) ? 1 : -1;
        ballYSpeed = (new Random().nextInt(2) == 0) ? 1 : -1;
        brick = new Brick[10][3];
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 3; j++) {
                brick[i][j] = new Brick((int) (i * (width/10) + i *2),
                        (int) (j * (height/10) + j * 2));
            }
        }

        bricksLeft = 30;
    }

}
